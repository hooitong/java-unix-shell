package sg.edu.nus.comp.cs4218.exception;

public class FmtException extends AbstractApplicationException {

	private static final long serialVersionUID = -3808957686975123140L;

	public FmtException(String message) {
		super("fmt: " + message);
	}
}